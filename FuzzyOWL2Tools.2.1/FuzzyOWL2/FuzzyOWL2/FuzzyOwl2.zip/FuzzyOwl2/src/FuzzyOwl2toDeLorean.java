
import java.util.*;

import fuzzyowl2.*;

import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.vocab.*;


/**
 * Class translating from OWL 2 into fuzzyDL syntax.
 *
 * @author Fernando Bobillo
 */
public class FuzzyOwl2toDeLorean extends FuzzyOwl2
{

	private static final double K1 = - Double.MAX_VALUE;
	private static final double K2 =   Double.MAX_VALUE;

	private Hashtable<String, TriangularModifier> triangularModifiers;
	private Hashtable<String, TrapezoidalFunction> trapezoidalNumbers;


	public FuzzyOwl2toDeLorean(String input, String output)
	{
		super(input, output);
		triangularModifiers = new Hashtable<String, TriangularModifier> ();
		trapezoidalNumbers = new Hashtable<String, TrapezoidalFunction> ();
	}


	@Override
	protected String getIndividualName(OWLIndividual i)
	{
		if (i.isAnonymous())
		{
			printError("Anonymous individual " + i + " not supported");
			return null;
		}
		else
			return( getShortName( i.asOWLNamedIndividual() )) ;
	}


	@Override
	protected String getTopConceptName()
	{
		return("*top*");
	}


	@Override
	protected String getBottomConceptName()
	{
		return("*bottom*");
	}


	@Override
	protected String getAtomicConceptName(OWLClass c)
	{
		return getShortName(c);
	}


	@Override
	protected String getObjectIntersectionOfName(Set<OWLClassExpression> operands)
	{
		String s = "(and ";
		for(OWLClassExpression c : operands)
			s += getClassName(c) + " ";
		s += ")";
		return s;
	}


	@Override
	protected String getObjectUnionOfName(Set<OWLClassExpression> operands)
	{
		String s = "(or ";
		for(OWLClassExpression c : operands)
			s += getClassName(c) + " ";
		s += ")";
		return s;
	}


	@Override
	protected String getObjectSomeValuesFromName(OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		return "(some " + getObjectPropertyName(p) + " " + getClassName(c) + " )";
	}


	@Override
	protected String getObjectAllValuesFromName(OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		return "(z-all " + getObjectPropertyName(p) + " " + getClassName(c) + " )";
	}


	@Override
	protected String getDataSomeValuesFromName(OWLDataPropertyExpression p, OWLDataRange range)
	{
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATATYPE)
		{
			String datatypeName = pm.getShortForm(range.asOWLDatatype());
			TrapezoidalFunction f = trapezoidalNumbers.get(datatypeName);
			if (f != null)
			{
				return "(some " + getDataPropertyName(p) + " (trapezoidal " +
						f.getA() + " " + f.getB() + " " + f.getC() + " " + f.getD() + " ) )";
			}
		}
		printError("Data some values restriction with range " + range + " not supported");
		return null;
	}


	@Override
	protected String getDataAllValuesFromName(OWLDataPropertyExpression p, OWLDataRange range)
	{
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATATYPE)
		{
			String datatypeName = pm.getShortForm(range.asOWLDatatype());
			TrapezoidalFunction f = trapezoidalNumbers.get(datatypeName);
			if (f != null)
			{
				return "(all " + getDataPropertyName(p) + " (trapezoidal " +
						f.getA() + " " + f.getB() + " " + f.getC() + " " + f.getD() + ") )";
			}
		}
		printError("Data all values restriction with range " + range + " not supported");
		return null;
	}


	@Override
	protected String getObjectComplementOfName(OWLClassExpression c)
	{
		return "(z-not " + getClassName(c) + " )";
	}


	@Override
	protected String getObjectHasSelfName(OWLObjectPropertyExpression p)
	{
		return "(self " + getObjectPropertyName(p) + ")";
	}


	@Override
	protected String getObjectOneOfName(Set<OWLIndividual> set)
	{
		String s = "(one-of ";
		for(OWLIndividual ind : set)
			s += getIndividualName(ind);
		s += ")";
		return s;
	}


	@Override
	protected String getObjectHasValueName(OWLObjectPropertyExpression p, OWLIndividual i)
	{
		return "some " + getObjectPropertyName(p) + " (one-of " + getIndividualName(i) + ") )";
	}


	@Override
	protected String getDataHasValueName(OWLDataPropertyExpression p, OWLLiteral lit)
	{
		printError("Data has value concept not supported");
		return null;
	}


	@Override
	protected String getObjectMinCardinalityRestrictionName(int card, OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		return "(at-least " + card + " " + getObjectPropertyName(p) + " " + getClassName(c) + " )";
	}


	@Override
	protected String getObjectMinCardinalityRestrictionName(int card, OWLObjectPropertyExpression p)
	{
		return "(at-least " + card + " " + getObjectPropertyName(p) + " )";
	}


	@Override
	protected String getObjectMaxCardinalityRestrictionName(int card, OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		return "(z-at-most " + card + " " + getObjectPropertyName(p) + " " + getClassName(c) + " )";
	}


	@Override
	protected String getObjectMaxCardinalityRestrictionName(int card, OWLObjectPropertyExpression p)
	{
		return "(z-at-most " + card + " " + getObjectPropertyName(p) + " )";
	}


	@Override
	protected String getObjectExactCardinalityRestrictionName(int card, OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		return "(exact " + card + " " + getObjectPropertyName(p) + " " + getClassName(c) + " )";
	}


	@Override
	protected String getObjectExactCardinalityRestrictionName(int card, OWLObjectPropertyExpression p)
	{
		return "(exact " + card + " " + getObjectPropertyName(p) + " )";
	}


	@Override
	protected String getDataMinCardinalityRestrictionName(int card, OWLDataPropertyExpression p, OWLDataRange range)
	{
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATATYPE)
		{
			String datatypeName = pm.getShortForm(range.asOWLDatatype());
			TrapezoidalFunction f = trapezoidalNumbers.get(datatypeName);
			if (f != null)
			{
				return "(at-least " + card + " " + getDataPropertyName(p) + " (trapezoidal " +
						f.getA() + " " + f.getB() + " " + f.getC() + " " + f.getD() + ") )";
			}
		}
		printError("Data min cardinality restriction with range " + range + " not supported");
		return null;
	}


	@Override
	protected String getDataMinCardinalityRestrictionName(int card, OWLDataPropertyExpression p)
	{
		return "(at-least " + card + " " + getDataPropertyName(p) + ")";
	}


	@Override
	protected String getDataMaxCardinalityRestrictionName(int card, OWLDataPropertyExpression p, OWLDataRange range)
	{
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATATYPE)
		{
			String datatypeName = pm.getShortForm(range.asOWLDatatype());
			TrapezoidalFunction f = trapezoidalNumbers.get(datatypeName);
			if (f != null)
			{
				return "(z-at-most " + card + " " + getDataPropertyName(p) + " (trapezoidal " +
						f.getA() + " " + f.getB() + " " + f.getC() + " " + f.getD() + ") )";
			}
		}
		printError("Data max cardinality restriction with range " + range + " not supported");
		return null;
	}


	@Override
	protected String getDataMaxCardinalityRestrictionName(int card, OWLDataPropertyExpression p)
	{
		return "(z-at-most " + card + " " + getDataPropertyName(p) + ")";
	}


	@Override
	protected String getDataExactCardinalityRestrictionName(int card, OWLDataPropertyExpression p, OWLDataRange range)
	{
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATATYPE)
		{
			String datatypeName = pm.getShortForm(range.asOWLDatatype());
			TrapezoidalFunction f = trapezoidalNumbers.get(datatypeName);
			if (f != null)
			{
				return "(exact " + card + " " + getDataPropertyName(p) + " (trapezoidal " +
						f.getA() + " " + f.getB() + " " + f.getC() + " " + f.getD() + ") )";
			}
		}
		printError("Data exact cardinality restriction with range " + range + " not supported");
		return null;
	}


	@Override
	protected String getDataExactCardinalityRestrictionName(int card, OWLDataPropertyExpression p)
	{
		return "(exact " + card + " " + getDataPropertyName(p) + ")";
	}



	@Override
	protected String getTopObjectPropertyName()
	{
		return("*top-role*");
	}


	@Override
	protected String getBottomObjectPropertyName()
	{
		printError("Bottom object property not supported");
		return null;
	}


	@Override
	protected String getAtomicObjectPropertyName(OWLObjectProperty p)
	{
		return getShortName(p);
	}


	@Override
	protected String getTopDataPropertyName()
	{
		return("*top-role*");
	}


	@Override
	protected String getBottomDataPropertyName()
	{
		printError("Bottom data property not supported");
		return null;
	}


	@Override
	protected String getAtomicDataPropertyName(OWLDataProperty p)
	{
		return getShortName(p);
	}


	@Override
	protected void writeFuzzyLogic(FuzzyLogic logic)
	{
		if (logic == FuzzyLogic.LUKASIEWICZ)
			printError("Lukasiewicz logic not supported");
	}


	@Override
	protected void writeConceptDeclaration(OWLClassExpression c)
	{
		print("(g-implies-concept " + getClassName(c) + " " + getTopConceptName() + ")");
	}


	@Override
	protected void writeDataPropertyDeclaration(OWLDataPropertyExpression dp)
	{
		print("(g-implies-role " + getDataPropertyName(dp) + " " + getTopDataPropertyName() + ")");
	}


	@Override
	protected void writeObjectPropertyDeclaration(OWLObjectPropertyExpression op)
	{
		print("(g-implies-role " + getObjectPropertyName(op) + " " + getTopObjectPropertyName() + ")");
	}


	@Override
	protected void writeTriangularModifierDefinition(String name, TriangularModifier mod)
	{
		triangularModifiers.put(name, mod);
	}


	@Override
	protected void writeLinearModifierDefinition(String name, LinearModifier mod)
	{
		printError("Linear modifier not supported");
	}


	@Override
	protected void writeLeftShoulderFunctionDefinition(String name, LeftShoulderFunction f)
	{
		trapezoidalNumbers.put(name, new TrapezoidalFunction(K1, K1, f.getA(), f.getB()) );
	}


	@Override
	protected void writeRightShoulderFunctionDefinition(String name, RightShoulderFunction f)
	{
		trapezoidalNumbers.put(name, new TrapezoidalFunction(f.getA(), f.getB(), K2, K2) );
	}


	@Override
	protected void writeLinearFunctionDefinition(String name, LinearFunction dat)
	{
		printError("Linear function datatype not supported");
	}


	@Override
	protected void writeTriangularFunctionDefinition(String name, TriangularFunction f)
	{
		trapezoidalNumbers.put(name, new TrapezoidalFunction(f.getA(), f.getB(), f.getB(), f.getC()) );
	}


	@Override
	protected void writeTrapezoidalFunctionDefinition(String name, TrapezoidalFunction f)
	{
		trapezoidalNumbers.put(name, new TrapezoidalFunction(f.getA(), f.getB(), f.getB(), f.getD()) );
	}


	@Override
	protected void writeModifiedFunctionDefinition(String name, ModifiedFunction dat)
	{
		printError("Modified datatype not supported");
	}


	@Override
	protected void writeModifiedPropertyDefinition(String name, ModifiedProperty c)
	{
		printError("Modified property not supported");
	}


	@Override
	protected void writeModifiedConceptDefinition(String name, ModifiedConcept c)
	{
		TriangularModifier mod = triangularModifiers.get(c.getFuzzyModifier());
		if (mod == null)
			exit("Error: Modifier " + mod + " not defined");
		else
			print("(equivalent-concepts " + name + " (triangular" + mod.getA() + " " +
					mod.getB() + " " + mod.getC() + " " + c.getFuzzyConcept() + ") )");
	}


	@Override
	protected void writeFuzzyNominalConceptDefinition(String name, FuzzyNominalConcept c)
	{
		print("(equivalent-concepts " + name + " (one-of " + c.getIndividual() +
				" " + c.getDegree() + ") )");
	}


	@Override
	protected void writeWeightedConceptDefinition(String name, WeightedConcept c)
	{
		printError("Weighted concept not supported");
	}


	@Override
	protected void writeWeightedMaxConceptDefinition(String name, WeightedMaxConcept c)
	{
		printError("Weighted maximum concept not supported");
	}


	@Override
	protected void writeWeightedMinConceptDefinition(String name, WeightedMinConcept c)
	{
		printError("Weighted minimum concept not supported");
	}


	@Override
	protected void writeWeightedSumConceptDefinition(String name, WeightedSumConcept c)
	{
		printError("Weighted sum concept not supported");
	}


	@Override
	protected void writeOwaConceptDefinition(String name, OwaConcept c)
	{
		print("OWA concept not supported");
	}


	@Override
	protected void writeChoquetConceptDefinition(String name, ChoquetConcept c)
	{
		print("Choquet concept not supported");
	}


	@Override
	protected void writeSugenoConceptDefinition(String name, SugenoConcept c)
	{
		print("Sugeno concept not supported");
	}


	@Override
	protected void writeQuasiSugenoConceptDefinition(String name, QuasiSugenoConcept c)
	{
		print("Quasi-Sugeno concept not supported");
	}


	@Override
	protected void writeQowaConceptDefinition(String name, QowaConcept c)
	{
		print("Quantifier-guided OWA concept not supported");
	}


	@Override
	protected void writeConceptAssertionAxiom(OWLIndividual i, OWLClassExpression c, double d)
	{
		print("(instance " + getIndividualName(i) + " " + getClassName(c) + " >= " + d + ")");
	}


	@Override
	protected void writeObjectPropertyAssertionAxiom(OWLIndividual i1, OWLIndividual i2, OWLObjectPropertyExpression p, double d)
	{
		print("(related " + getIndividualName(i1) + " " + getIndividualName(i2) + " " + getObjectPropertyName(p) + " >= " + d + ")");
	}


	@Override
	protected void writeDataPropertyAssertionAxiom(OWLIndividual i1, OWLLiteral i2, OWLDataPropertyExpression p, double d)
	{
		try {
			Double lit = Double.parseDouble(i2.getLiteral());
			print("(instance " + getIndividualName(i1) + " (trapezoidal " + lit +
					" " +  lit + " " + lit + " " + lit + ") >= " + d + ")");
		}
		catch (NumberFormatException ex)
		{
			printError("Data property assertion (related " + i1 + ", " + i2
					+ ") " + p + " >= " + d + " not supported");
		}
	}


	@Override
	protected void writeNegativeObjectPropertyAssertionAxiom(OWLIndividual i1, OWLIndividual i2, OWLObjectPropertyExpression p, double d)
	{
		print("(z-not-related " + getIndividualName(i1) + " " + getIndividualName(i2) + " " + getObjectPropertyName(p) + " >= " + d + ")");
	}


	@Override
	protected void writeNegativeDataPropertyAssertionAxiom(OWLIndividual i1, OWLLiteral i2, OWLDataPropertyExpression p, double d)
	{
		printError("Negative data property assertion not supported");
	}


	@Override
	protected void writeSameIndividualAxiom(Set<OWLIndividual> set)
	{
		String first = null;
		for (OWLIndividual ind : set)
		{
			if (first == null)
				first = getIndividualName(ind);
			else
				print("(same-as " + first + " " + getIndividualName(ind) + ")");
		}
	}


	@Override
	protected void writeDifferentIndividualsAxiom(Set<OWLIndividual> set)
	{
		for (OWLIndividual ind1 : set)
		{
			String first = getIndividualName(ind1);
			boolean flag = false;
			for (OWLIndividual ind2 : set)
			{
				if (flag)
					print("(different-to " + first + " " + getIndividualName(ind2) + ")");
				else
					if (ind1.equals(ind2))
						flag = true;
			}
		}
	}


	@Override
	protected void writeDisjointClassesAxiom(Set<OWLClassExpression> set)
	{
		if (set.size() > 1)
		{
			String s = "(disjoint-concepts ";
			for (OWLClassExpression c : set)
				s += getClassName(c) + " ";
			s += ")";
			print(s);
		}
	}


	@Override
	protected void writeDisjointUnionAxiom(Set<OWLClassExpression> set)
	{
		if (set.size() > 1)
		{
			String s = "(disjoint-union-concept ";
			for (OWLClassExpression c : set)
				s += getClassName(c) + " ";
			s += ")";
			print(s);
		}
	}


	@Override
	protected void writeSubclassOfAxiom(OWLClassExpression subclass, OWLClassExpression superclass, double d)
	{
		print("(g-implies-concept " + getClassName(subclass) + " " + getClassName(superclass) + " >= " + d + ")");
	}


	@Override
	protected void writeEquivalentClassesAxiom(Set<OWLClassExpression> set)
	{
		String first = null;
		for (OWLClassExpression c : set)
		{
			if (first == null)
				first = getClassName(c);
			else
				print("(equivalent-concepts " + first + " " + getClassName(c) + ")");
		}
	}


	@Override
	protected void writeSubObjectPropertyOfAxiom(OWLObjectPropertyExpression subProperty, OWLObjectPropertyExpression superProperty, double d)
	{
//		if (superProperty.isOWLTopObjectProperty() == false)
			print("(g-implies-role " + getObjectPropertyName(subProperty) + " " + getObjectPropertyName(superProperty) + " >= " + d + ")");
	}


	@Override
	protected void writeSubPropertyChainOfAxiom(List<OWLObjectPropertyExpression> chain, OWLObjectPropertyExpression superProperty, double d)
	{
		if (chain.size() > 0)
		{
			String s = "(g-implies ";
			for (OWLObjectPropertyExpression p : chain)
				s += getObjectPropertyName(p) + " ";
			s += ")";
			print(s + " " + getObjectPropertyName(superProperty) + " >= " + d + ")");
		}
	}


	@Override
	protected void writeSubDataPropertyOfAxiom(OWLDataPropertyExpression subProperty, OWLDataPropertyExpression superProperty, double d)
	{
//		if (superProperty.isOWLTopDataProperty() == false)
			print("(g-implies-role " + getDataPropertyName(subProperty) + " " + getDataPropertyName(superProperty) + " >= " + d + ")");
	}


	@Override
	protected void writeEquivalentObjectPropertiesAxiom(Set<OWLObjectPropertyExpression> set)
	{
		String first = null;
		for (OWLObjectPropertyExpression p : set)
		{
			if (first == null)
				first = getObjectPropertyName(p);
			else
				print("(equivalent-roles " + first + " " + getObjectPropertyName(p) + ")");
		}
	}


	@Override
	protected void writeEquivalentDataPropertiesAxiom(Set<OWLDataPropertyExpression> set)
	{
		String first = null;
		for (OWLDataPropertyExpression p : set)
		{
			if (first == null)
				first = getDataPropertyName(p);
			else
				print("(equivalent-roles " + first + " " + getDataPropertyName(p) + ")");
		}
	}


	@Override
	protected void writeTransitiveObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(transitive " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeSymmetricObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(symmetric " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeAsymmetricObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(asymmetric " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeReflexiveObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(reflexive " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeIrreflexiveObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(irreflexive " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeFunctionalObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("(functional " + getObjectPropertyName(p) + ")");
	}


	@Override
	protected void writeFunctionalDataPropertyAxiom(OWLDataPropertyExpression p)
	{
		print("(functional " + getDataPropertyName(p) + ")");
	}


	@Override
	protected void writeInverseObjectPropertiesAxiom(OWLObjectPropertyExpression p1, OWLObjectPropertyExpression p2)
	{
		print("(inverse " + getObjectPropertyName(p1) + " " + getObjectPropertyName(p2) + ")");
	}


	@Override
	protected void writeInverseFunctionalObjectPropertyAxiom(OWLObjectPropertyExpression p)
	{
		print("inverse-functional " + getObjectPropertyName(p));
	}


	@Override
	protected void writeObjectPropertyDomainAxiom(OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		print("(domain " + getObjectPropertyName(p) + " " + getClassName(c) + ")");
	}


	@Override
	protected void writeObjectPropertyRangeAxiom(OWLObjectPropertyExpression p, OWLClassExpression c)
	{
		print("(z-range " + getObjectPropertyName(p) + " " + getClassName(c) + ")");
	}


	@Override
	protected void writeDataPropertyDomainAxiom(OWLDataPropertyExpression p, OWLClassExpression c)
	{
		print("(domain " + getDataPropertyName(p) + " " + getClassName(c) + ")");
	}


	@Override
	protected void writeDataPropertyRangeAxiom(OWLDataPropertyExpression p, OWLDataRange range)
	{
		String rangeString = null;
		DataRangeType type = range.getDataRangeType();
		if (type == DataRangeType.DATA_INTERSECTION_OF)
		{
			int correctness = 0;
			double min = 0;
			double max = 0;
			Set<OWLDataRange> set = ((OWLDataIntersectionOf) range).getOperands();
			if (set.size() == 2)
			{
				for (OWLDataRange dr2 : set)
				{
					if (dr2.getDataRangeType() == DataRangeType.DATATYPE_RESTRICTION)
					{
						Set<OWLFacetRestriction> set2 = ((OWLDatatypeRestriction) dr2).getFacetRestrictions();
						if (set2.size() != 1)
							continue;

						OWLFacetRestriction facet = set2.iterator().next();
						String val = facet.getFacetValue().getLiteral();
						double k = Double.parseDouble(val);
						if (facet.getFacet() == OWLFacet.MIN_INCLUSIVE)
						{
							min = k;
							correctness++;
						}
						else if (facet.getFacet() == OWLFacet.MAX_INCLUSIVE)
						{
							max = k;
							correctness++;
						}
					}
				}
			}

			if (correctness == 2)
				rangeString = "(trapezoidal " + min + " " + min + " " + max + " " + max + ")";
		}

		if (rangeString != null)
			print("(g-implies *top* (all " + getDataPropertyName(p) + " " + rangeString + " ) )");
		else
			printError("Data property range axiom not supported");
	}


	@Override
	protected void writeDisjointObjectPropertiesAxiom(Set<OWLObjectPropertyExpression> set)
	{
		if (set.size() > 1)
		{
			String s = "(disjoint-roles ";
			for (OWLObjectPropertyExpression p : set)
				s += getObjectPropertyName(p) + " ";
			s += ")";
			print(s);
		}
	}


	@Override
	protected void writeDisjointDataPropertiesAxiom(Set<OWLDataPropertyExpression> set)
	{
		if (set.size() > 1)
		{
			String s = "(disjoint-roles ";
			for (OWLDataPropertyExpression p : set)
				s += getDataPropertyName(p) + " ";
			s += ")";
			print(s);
		}
	}


	/**
	 * @param args Two arguments: the input OWL 2 ontology, and the output fuzzy ontology in fuzzyDL syntax.
	 */
	public static void main(String[] args)
	{
		String[] returnValue = processParameters(args);
		FuzzyOwl2toDeLorean f = new FuzzyOwl2toDeLorean(returnValue[0], returnValue[1]);
		f.translateOwl2Ontology();
	}


	private boolean isReservedWord(String s)
	{
		if (s.equals("triangular"))
			return true;

		return false;
	}


	@Override
	protected String getShortName(OWLEntity e)
	{
		String aux = pm.getShortForm(e);
		if (isReservedWord(aux))
			return "_" + aux;
		else
			return aux;
	}

}
