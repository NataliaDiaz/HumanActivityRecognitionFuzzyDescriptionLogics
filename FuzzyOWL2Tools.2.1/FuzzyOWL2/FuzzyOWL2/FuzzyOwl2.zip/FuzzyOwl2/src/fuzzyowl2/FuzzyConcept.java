package fuzzyowl2;

/**
 * Abstract class representing a fuzzy concept.
 *
 * @author Fernando Bobillo
 */
public abstract class FuzzyConcept
{

}
