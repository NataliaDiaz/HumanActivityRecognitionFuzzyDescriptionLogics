package fuzzyowl2;

/**
 * Abstract class representing a fuzzy property.
 *
 * @author Fernando Bobillo
 */
public abstract class FuzzyProperty
{

}
